const assert = require('chai').assert;

describe('discoverSynonymFieldNames', () => {
  it('mock test', () => {
    assert.equal(true, true);
  });
});
