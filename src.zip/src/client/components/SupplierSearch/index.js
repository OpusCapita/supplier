import SupplierSearch from './SupplierSearch.react.js';

export default SupplierSearch;
