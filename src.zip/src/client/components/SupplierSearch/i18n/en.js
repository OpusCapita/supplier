let SupplierSearch = {
  label: 'Search by name, city, VAT id, Tax id, registration number, DUNS number, or Global Location Number',
  search: 'Search'
};

export default {
  SupplierSearch: SupplierSearch
};
