let SupplierSearch = {
  label: 'Suche nach Name, Stadt, Umsatzsteuer-ID, Steuernummer, Registrierungsnummer, DUNS-Nummer oder Global Location Number',
  search: 'Suche'
};

export default {
  SupplierSearch: SupplierSearch
};
