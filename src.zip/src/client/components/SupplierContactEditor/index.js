import SupplierContactEditor from './SupplierContactEditor.react.js';

export default SupplierContactEditor;
