import Label from './Label.react.js';

export default Label;
