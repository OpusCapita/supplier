import SupplierProfileStrength from './SupplierProfileStrength.react.js';

export default SupplierProfileStrength;
