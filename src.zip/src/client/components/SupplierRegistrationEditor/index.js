import SupplierRegistrationEditor from './SupplierRegistrationEditor.react.js';

export default SupplierRegistrationEditor;
