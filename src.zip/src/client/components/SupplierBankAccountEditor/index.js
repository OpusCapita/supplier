import SupplierBankAccountEditor from './SupplierBankAccountEditor.react';

export default SupplierBankAccountEditor;
