import SupplierEditor from './SupplierEditor.react.js';

export default SupplierEditor;
