import SupplierAccess from './SupplierAccess.react.js';

export default SupplierAccess;
