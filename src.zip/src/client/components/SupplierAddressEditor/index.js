import SupplierAddressEditor from './SupplierAddressEditor.react.js';

export default SupplierAddressEditor;
