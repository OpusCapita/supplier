import ReferenceSearchDialog from './ReferenceSearchDialog.react';

export default ReferenceSearchDialog;
