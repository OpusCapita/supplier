export default {
  ReferenceSearchDialog: {
    noItemsSelectedMessage: 'Bitte wählen Sie mindestens ein Element aus.',
    selectLabel: 'Wählen',
    resetLabel: 'Zurücksetzen',
    searchLabel: 'Suchen',
    itemsFound: "{number} Datensätze gefunden"
  }
};
