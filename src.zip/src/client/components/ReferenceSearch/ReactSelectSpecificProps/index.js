import { PropTypes } from 'react';

export default {
  clearable: PropTypes.bool,
  onOpen: PropTypes.func,
  className: PropTypes.string
}
