import PaginationPanel from './PaginationPanel.react';

export default PaginationPanel;
