import ReferenceSearchInput from './ReferenceSearchInput.react';

export default ReferenceSearchInput;
