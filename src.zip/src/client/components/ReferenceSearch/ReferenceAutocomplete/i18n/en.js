let ReferenceAutocomplete = {};
ReferenceAutocomplete.clearValueText = "Clear";
ReferenceAutocomplete.clearAllText = "Clear all";
ReferenceAutocomplete.noResultsText = "Nothing found. Please modify your search criteria.";
ReferenceAutocomplete.placeholder = "Click to add values";
ReferenceAutocomplete.loadingPlaceholder = "Please wait...";

export default {
  ReferenceAutocomplete: ReferenceAutocomplete
};
