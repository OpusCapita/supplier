let ReferenceAutocomplete = {
  clearValueText: "Löschen",
  clearAllText: "Alles löschen",
  noResultsText: "Kein Suchergebnis. Bitte ändern Sie die Suchkriterien und versuchen Sie es erneut.",
  placeholder: "Klicken Sie hier, um Werte hinzuzufügen",
  loadingPlaceholder: "Bitte warten..."
}

export default {
  ReferenceAutocomplete: ReferenceAutocomplete
};
