let SupplierInput = {};
SupplierInput.supplierId = 'Lieferanten ID';
SupplierInput.supplierName = 'Lieferantenname';
SupplierInput.supplierGroupName = 'Lieferantengruppe';
SupplierInput.dialogTitle = 'Suche nach Lieferanten';

export default {
  SupplierInput: SupplierInput
};

