let SupplierInput = {};
SupplierInput.supplierId = 'Supplier ID';
SupplierInput.supplierName = 'Supplier Name';
SupplierInput.supplierGroupName = 'Supplier Group';
SupplierInput.dialogTitle = 'Search for Suppliers';

export default {
  SupplierInput: SupplierInput
};
