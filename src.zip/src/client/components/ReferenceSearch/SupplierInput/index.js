import SupplierInput from './SupplierInput.react'

export default SupplierInput;
