import SortableColumn from './SortableColumn.react';

export default SortableColumn;
