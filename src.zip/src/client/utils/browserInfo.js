module.exports.isIE = function() {
  return false || !!document.documentMode;
}
